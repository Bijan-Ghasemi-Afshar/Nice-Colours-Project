/***************************************** Functions for different Schemas ********************************/
function complementaryColorScheme(){

	reset()

	var colourGotten;					

	colourGotten = getRandomColor();

	// var hslFormula = 'hsl(' + colourGotten + ', ' +
	//  randomIntFromInterval(30,100) + '%, ' + randomIntFromInterval(20,80) + '%)';	
	var hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, ' + randomIntFromInterval(20,50) + '%)';
	changeBackground("colour1", hslFormula);
	var theRGB = getTheColour("colour1");
	changeHTML("colour1", theRGB);			
	changeColor("colour1", "white");
	changeBackground("website-example", hslFormula);		

	// hslFormula = 'hsl(' + getContrast50(colourGotten) + ', ' +
	//  randomIntFromInterval(30,100) + '%, '+ randomIntFromInterval(20,80) + '%)';
	hslFormula = 'hsl(' + getContrast50(colourGotten) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour2", hslFormula);
	theRGB = getTheColour("colour2");
	changeHTML("colour2", theRGB);			
	changeColor("example1", hslFormula);
	changeColor("example2", hslFormula);
	changeColor("example3", hslFormula);	

	dispalyON('colour1');
	dispalyON('colour2');	
}


function analogousColorScheme(){

	reset()

	var colourGotten;
	var counter = 0;

	colourGotten = getRandomColor();

	var hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, ' + randomIntFromInterval(20,50) + '%)';
	changeBackground("colour1", hslFormula);
	var theRGB = getTheColour("colour1");
	changeHTML("colour1", theRGB);	
	changeColor("colour1", "white");			
	counter++;
	changeBackground("website-example", hslFormula);


	colourGotten = getAnalogous(colourGotten);
	hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour2", hslFormula);
	theRGB = getTheColour("colour2");
	changeHTML("colour2", theRGB);		
	counter++;
	changeColor("example1", hslFormula);
	changeColor("example2", hslFormula);
	

	hslFormula = 'hsl(' + getAnalogous(colourGotten) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour3", hslFormula);
	theRGB = getTheColour("colour3");
	changeHTML("colour3", theRGB);	
	changeColor("example3", hslFormula);

	dispalyON('colour1');	
	dispalyON('colour2');	
	dispalyON('colour3');	
}



function triadicColorScheme(){

	reset()		

	var colourGotten;
	var counter = 0;

	colourGotten = getRandomColor();

	var hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, ' + randomIntFromInterval(20,50) + '%)';
	changeBackground("colour1", hslFormula);
	var theRGB = getTheColour("colour1");
	changeHTML("colour1", theRGB);	
	changeColor("colour1", "white");
	counter++;
	changeBackground("website-example", hslFormula);


	colourGotten = getTriadic(colourGotten);
	hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour2", hslFormula);
	theRGB = getTheColour("colour2");
	changeHTML("colour2", theRGB);	
	changeColor("colour1", "white");
	counter++;
	changeColor("example1", hslFormula);
	changeColor("example2", hslFormula);
	

	hslFormula = 'hsl(' + getTriadic(colourGotten) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour3", hslFormula);
	theRGB = getTheColour("colour3");
	changeHTML("colour3", theRGB);	
	changeColor("example3", hslFormula);

	dispalyON('colour1');	
	dispalyON('colour2');	
	dispalyON('colour3');	
	
}



function splitComplementary(){

	reset()

	var colourGotten;
	var counter = 0;

	colourGotten = getRandomColor();

	var hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, ' + randomIntFromInterval(20,50) + '%)';
	changeBackground("colour1", hslFormula);
	var theRGB = getTheColour("colour1");
	changeHTML("colour1", theRGB);		
	changeColor("colour1", "white");
	counter++;
	changeBackground("website-example", hslFormula);


	colourGotten = getSplitComplementary(colourGotten, counter);
	hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour2", hslFormula);
	theRGB = getTheColour("colour2");
	changeHTML("colour2", theRGB);	
	counter++;
	changeColor("example1", hslFormula);
	changeColor("example2", hslFormula);
	

	hslFormula = 'hsl(' + getSplitComplementary(colourGotten, counter) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour3", hslFormula);
	theRGB = getTheColour("colour3");
	changeHTML("colour3", theRGB);	
	changeColor("example3", hslFormula);

	dispalyON('colour1');	
	dispalyON('colour2');	
	dispalyON('colour3');	
	
}



function rectangleColorScheme(){
	
	var colourGotten;
	var recColour1;
	var recColour2;
	var counter = 0;

	colourGotten = getRandomColor();
	recColour1 = colourGotten;
	var hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, ' + randomIntFromInterval(20,50) + '%)';
	changeBackground("colour1", hslFormula);
	var theRGB = getTheColour("colour1");
	changeHTML("colour1", theRGB);		
	changeColor("colour1", "white");
	changeBackground("website-example", hslFormula);


	colourGotten = getRectangle60(colourGotten);
	recColour2 = colourGotten;
	hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, '+ randomIntFromInterval(20,50) + '%)';
	changeBackground("colour2", hslFormula);
	theRGB = getTheColour("colour2");
	changeHTML("colour2", theRGB);	
	changeColor("colour2", "white");
	changeColor("example1", hslFormula);


	hslFormula = 'hsl(' + getContrast50(recColour1) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour3", hslFormula);
	theRGB = getTheColour("colour3");
	changeHTML("colour3", theRGB);	
	changeColor("example2", hslFormula);



	hslFormula = 'hsl(' + getContrast50(recColour2) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour4", hslFormula);
	theRGB = getTheColour("colour4");
	changeHTML("colour4", theRGB);		
	changeColor("example3", hslFormula);

	dispalyON('colour1');	
	dispalyON('colour2');	
	dispalyON('colour3');	
	dispalyON('colour4');	

}



function squareColorScheme(){
	
	var colourGotten;
	var recColour1;
	var recColour2;
	var counter = 0;

	colourGotten = getRandomColor();
	recColour1 = colourGotten;
	var hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, ' + randomIntFromInterval(20,50) + '%)';
	changeBackground("colour1", hslFormula);
	var theRGB = getTheColour("colour1");
	changeHTML("colour1", theRGB);		
	changeColor("colour1", "white");
	changeBackground("website-example", hslFormula);


	colourGotten = getsquare90(colourGotten);	
	hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(20,65) + '%, '+ randomIntFromInterval(20,50) + '%)';
	changeBackground("colour2", hslFormula);
	theRGB = getTheColour("colour2");
	changeHTML("colour2", theRGB);		
	changeColor("colour2", "white");
	changeColor("example1", hslFormula);


	colourGotten = getsquare90(colourGotten);
	hslFormula = 'hsl(' + colourGotten + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour3", hslFormula);
	theRGB = getTheColour("colour3");
	changeHTML("colour3", theRGB);		
	changeColor("example2", hslFormula);



	hslFormula = 'hsl(' + getsquare90(colourGotten) + ', ' +
	 randomIntFromInterval(60,100) + '%, '+ randomIntFromInterval(50,95) + '%)';
	changeBackground("colour4", hslFormula);
	theRGB = getTheColour("colour4");
	changeHTML("colour4", theRGB);	
	changeColor("example3", hslFormula);

	dispalyON('colour1');	
	dispalyON('colour2');	
	dispalyON('colour3');	
	dispalyON('colour4');	

}

/********************************SWITCHING FUNCTIONS********************************/
function switchComplementaryColours(){
	var colour1 = document.getElementById("example1").style.color;	
	var colour2 = document.getElementById("website-example").style.backgroundColor;	
	changeBackground("website-example", colour1);
	changeColor("example1", colour2);
	changeColor("example2", colour2);
	changeColor("example3", colour2);
}

var switchThreeCounter = 0;
function swtichThreeColours(){
	switchThreeCounter++;
	if(switchThreeCounter % 2 != 0){
		var colour2 = document.getElementById("example1").style.color;	
		var colour3 = document.getElementById("example3").style.color;				
		changeColor("example1", colour3);
		changeColor("example2", colour3);
		changeColor("example3", colour2);
	} else {
		var colour2 = document.getElementById("example1").style.color;			
		var colour1 = document.getElementById("website-example").style.backgroundColor;	
		changeBackground("website-example", colour2);
		changeColor("example1", colour1);
		changeColor("example2", colour1);		
	}		
}

var switchFourCounter = 0;
	function swtichFourColours(){
		switchFourCounter++;
		if(switchFourCounter % 6 == 0){
			var colour1 = document.getElementById("website-example").style.backgroundColor;
			var colour2 = document.getElementById("example1").style.color;
			var colour3 = document.getElementById("example2").style.color;
			var colour4 = document.getElementById("example3").style.color;
			changeBackground("website-example", colour2);
			changeColor("example1", colour1);					
		} else if(switchFourCounter % 2 == 0){
			var colour1 = document.getElementById("example1").style.color;			
			var colour2 = document.getElementById("example2").style.color;				
			changeColor("example1", colour2);
			changeColor("example2", colour1);			
		} else if(switchFourCounter % 2 != 0){
			var colour1 = document.getElementById("example2").style.color;	
			var colour2 = document.getElementById("example3").style.color;							
			changeColor("example2", colour2);
			changeColor("example3", colour1);
		}
		
	}

/********************************RUNNING the Page and FUNCTIONS********************************/
function generateColours(){		

	var option1 = document.getElementById("option1");
	if(option1.checked){
		complementaryColorScheme();
	} else if(option2.checked)	{
		analogousColorScheme();
	} else if(option3.checked)	{
		triadicColorScheme();
	} else if(option4.checked)	{
		splitComplementary();
	} else if(option5.checked)	{
		rectangleColorScheme();
	} else if(option6.checked)	{
		squareColorScheme();
	}
}

function switchColours(){

	if(option1.checked){
		switchComplementaryColours();
	} else if(option2.checked || option3.checked || option4.checked){
		swtichThreeColours();
	} else if(option5.checked || option6.checked){
		swtichFourColours();
	}

}


/******************************* The Random Colours ********************************/
function getRandomColor() 
{
    var randomHue = Math.floor((Math.random() * 359) + 1);        
    return randomHue;
}

function betweenSomething()
{
	return Math.floor((Math.random() * 99) + 1);
}

function randomIntFromInterval(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}

function getContrast50(color)
{
	if(color >= 180){

		color -= 180;

	} else {

		color += 180;

	}

	return color;		
}

function getAnalogous(colour)
{
	return colour + 30;
}

function getTriadic(colour)
{

	return colour + 120;
}

function getSplitComplementary(colour, counter)
{
	if(counter == 1){
		return colour + 60;
	} 
	else if(counter == 2){
		return colour + 150;
	}
}

function getRectangle60(colour)
{
	return colour + 60;
}

function getsquare90(color)
{
	return color + 90;
}

/******************************* Extra Functions ********************************/
function changeBackground(id, colour)
{
	document.getElementById(id).style.backgroundColor = colour;
}

function changeColor(id, colour)
{
	document.getElementById(id).style.color = colour;
}

function changeHTML(id, text)
{
	document.getElementById(id).innerHTML = text ;
}

function removeHTML(id)
{
	document.getElementById(id).innerHTML = "";
}

function getTheColour(id){
	return document.getElementById(id).style.backgroundColor;
}

function reset(){
	changeBackground("colour1", "white");
	changeBackground("colour2", "white");
	changeBackground("colour3", "white");
	changeBackground("colour4", "white");	
	displayOFF("colour3");	
	displayOFF("colour4");
}

function dispalyON(id){
	document.getElementById(id).style.display = 'block';
}

function displayOFF(id){
	document.getElementById(id).style.display = 'none';
}
